self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "81ad601d70c065e977069ba60ad26550",
    "url": "/pwa/chart.css"
  },
  {
    "revision": "199d521815b06d9f145564429b2fa135",
    "url": "/pwa/charting_library/charting_library.min.d.ts"
  },
  {
    "revision": "ef0cae665eff2b36aa221f220095461c",
    "url": "/pwa/charting_library/charting_library.min.js"
  },
  {
    "revision": "e6990665491f234801635cd9365ea94b",
    "url": "/pwa/charting_library/datafeed-api.d.ts"
  },
  {
    "revision": "ebb10f63d339bd1be70583048a6debe9",
    "url": "/pwa/charting_library/static/ar-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "30969e5264d2ce0e8eb4c4461e82a8db",
    "url": "/pwa/charting_library/static/bundles/10.0b4b80ce7284d28083f7.js"
  },
  {
    "revision": "d56c67808481aeeee4e098dbbc9e3f92",
    "url": "/pwa/charting_library/static/bundles/13.87c51bb601702992e1dd.js"
  },
  {
    "revision": "64907e79eeaf7e10bd1aa14f18f5b51e",
    "url": "/pwa/charting_library/static/bundles/15.d0280d7e7496e08f4962.js"
  },
  {
    "revision": "957128907cb99fc409d0fc0eeb443425",
    "url": "/pwa/charting_library/static/bundles/9.0f95ea8c401ed7b42af8.js"
  },
  {
    "url": "/pwa/charting_library/static/bundles/crosshair.6c091f7d5427d0c5e6d9dc3a90eb2b20.cur"
  },
  {
    "url": "/pwa/charting_library/static/bundles/dot.ed68e83c16f77203e73dbc4c3a7c7fa1.cur"
  },
  {
    "revision": "6b9f3182125c185a11b1492914c2d654",
    "url": "/pwa/charting_library/static/bundles/ds-property-pages.4650c8fe6629bba016a1.js"
  },
  {
    "revision": "ee605d2ea8a9f00cd9d35438a3c451c7",
    "url": "/pwa/charting_library/static/bundles/editobjectdialog.1a53a3b4104302264052.js"
  },
  {
    "url": "/pwa/charting_library/static/bundles/eraser.0579d40b812fa2c3ffe72e5803a6e14c.cur"
  },
  {
    "revision": "e81b7725d3723571e6d5bc393e37d936",
    "url": "/pwa/charting_library/static/bundles/go-to-date-dialog-impl.4e462a33aa18010573c8.js"
  },
  {
    "url": "/pwa/charting_library/static/bundles/grab.bc156522a6b55a60be9fae15c14b66c5.cur"
  },
  {
    "url": "/pwa/charting_library/static/bundles/grabbing.1c0862a8a8c0fb02885557bc97fdafe7.cur"
  },
  {
    "revision": "ad5bc594dd3447526c4fbad67b15ca40",
    "url": "/pwa/charting_library/static/bundles/ie-fallback-logos.58dc8877847b4dced0e4.js"
  },
  {
    "revision": "22d11ea9a77a8caf8f9d9be7b663d20e",
    "url": "/pwa/charting_library/static/bundles/lazy-jquery-ui.ca86274e39963e6b5b5f.js"
  },
  {
    "revision": "dca8d93f6f7740573778e1f98b8d557f",
    "url": "/pwa/charting_library/static/bundles/lazy-velocity.6843186d1d19426e2f3c.js"
  },
  {
    "revision": "edef1e086a66d4e147a8cb5e94fbd350",
    "url": "/pwa/charting_library/static/bundles/library.01b9186ecddcadea2011.js"
  },
  {
    "revision": "d91301a3c3dc569eaf036807cefedeae",
    "url": "/pwa/charting_library/static/bundles/library.9ce31e2f432531c1bfc826e207d21a1e.css"
  },
  {
    "revision": "e27f45cf3086fbc5b6206f426dd77374",
    "url": "/pwa/charting_library/static/bundles/lt-pane-views.9ecc943f945b2fd4fad6.js"
  },
  {
    "revision": "e691e4436be29fa61d6a9c858d730ce8",
    "url": "/pwa/charting_library/static/bundles/objecttreedialog.e2f61129ab1c8c59ca83.js"
  },
  {
    "revision": "bbc7233033b48dc30aa178b978e52f57",
    "url": "/pwa/charting_library/static/bundles/propertypagesfactory.88d1e4b5f0c82c2d9b43.js"
  },
  {
    "revision": "390b11d5cd5b5dbe2d18f3c5558602db",
    "url": "/pwa/charting_library/static/bundles/symbol-info-dialog-impl.1d95eab19af70ebdf07d.js"
  },
  {
    "revision": "564dca156105962a094729c581b56890",
    "url": "/pwa/charting_library/static/bundles/take-chart-image-dialog-impl.45288e052b450c5e2d11.js"
  },
  {
    "revision": "fad6a7e07820f46b60a123b597e4c55a",
    "url": "/pwa/charting_library/static/bundles/vendors.838cbe47eebe3eb9244f.js"
  },
  {
    "url": "/pwa/charting_library/static/bundles/vendors.a94ef44ed5c201cefcf6ad7460788c1a.css"
  },
  {
    "url": "/pwa/charting_library/static/bundles/zoom.e21f24dd632c7069139bc47ae89c54b5.cur"
  },
  {
    "revision": "56aec5c2245a1d8db092a1813a23979f",
    "url": "/pwa/charting_library/static/cs-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "4cc8e6787eb882b93a25532c2493012c",
    "url": "/pwa/charting_library/static/da_DK-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "e2894de7cfe4e85e7417335b2db650b8",
    "url": "/pwa/charting_library/static/de-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "c9c298343132ff355f719d966b0e49f1",
    "url": "/pwa/charting_library/static/el-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "006c0e1bccb535fabc2436d3378214c3",
    "url": "/pwa/charting_library/static/en-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "f839f01eac0baa9235e64d51683a4011",
    "url": "/pwa/charting_library/static/es-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "6ca9dea7ff86ba152492e03f56846655",
    "url": "/pwa/charting_library/static/et_EE-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "3a4b90b0ffe35fb463da8419e4781ccf",
    "url": "/pwa/charting_library/static/fa-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "b526f0637e912fae979bcfe9f0c9bd74",
    "url": "/pwa/charting_library/static/fonts/fontawesome-webfont.svg"
  },
  {
    "revision": "dcb26c7239d850266941e80370e207c1",
    "url": "/pwa/charting_library/static/fonts/fontawesome-webfont.ttf"
  },
  {
    "revision": "3293616ec0c605c7c2db25829a0a509e",
    "url": "/pwa/charting_library/static/fonts/fontawesome-webfont.woff"
  },
  {
    "revision": "257663948b02c949d8be23027a10fb65",
    "url": "/pwa/charting_library/static/fr-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "13393cf6eead1e85374120414509d18b",
    "url": "/pwa/charting_library/static/he_IL-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "fc492451c7d00e7090e4f996ca97a21e",
    "url": "/pwa/charting_library/static/hu_HU-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "ce5756dba71cbe80b9908b7f4ced85d2",
    "url": "/pwa/charting_library/static/id_ID-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "de4b60f320301ee166720e6d2d3ff610",
    "url": "/pwa/charting_library/static/images/balloon.png"
  },
  {
    "revision": "8443ec594898865ce13f99215e8e82a4",
    "url": "/pwa/charting_library/static/images/bar-loader.gif"
  },
  {
    "revision": "d63a510d236b6d907751861c1a64f178",
    "url": "/pwa/charting_library/static/images/button-bg.png"
  },
  {
    "revision": "9e2b0f1fa8b3c3e5cf9118b90d45516a",
    "url": "/pwa/charting_library/static/images/charting_library/logo-widget-copyright-faded.png"
  },
  {
    "revision": "c4488f0e1b4e79375954db45c277a4fa",
    "url": "/pwa/charting_library/static/images/charting_library/logo-widget-copyright.png"
  },
  {
    "revision": "d780f1c36cbcb871e472f5d4d6e44ed0",
    "url": "/pwa/charting_library/static/images/controlll.png"
  },
  {
    "revision": "8682e2fac65301c60452b266993ea1c4",
    "url": "/pwa/charting_library/static/images/delayed.png"
  },
  {
    "revision": "683e7a8e04465dc3fac39ed37f0789b8",
    "url": "/pwa/charting_library/static/images/dialogs/checkbox.png"
  },
  {
    "revision": "5eba9d15b8bccbc1dcf2df5e3352d963",
    "url": "/pwa/charting_library/static/images/dialogs/close-flat.png"
  },
  {
    "revision": "3b724056f9d4327a041971236b872c2b",
    "url": "/pwa/charting_library/static/images/dialogs/large-slider-handle.png"
  },
  {
    "revision": "4a9abefd31dab7c8239e02e925aacd78",
    "url": "/pwa/charting_library/static/images/dialogs/linewidth-slider.png"
  },
  {
    "revision": "7e0cc5f7d7f5151500dd60b8d6ca60a1",
    "url": "/pwa/charting_library/static/images/dialogs/opacity-slider.png"
  },
  {
    "revision": "1df47f578aeef40dd1f2328338a133be",
    "url": "/pwa/charting_library/static/images/icons.png"
  },
  {
    "revision": "932c209e6bf69970ca313047d5da8964",
    "url": "/pwa/charting_library/static/images/prediction-clock-black.png"
  },
  {
    "revision": "f55394b616ed1ae9462c37daab941d93",
    "url": "/pwa/charting_library/static/images/prediction-clock-white.png"
  },
  {
    "revision": "898929f1acdb622689e0fc0c95c8fcd0",
    "url": "/pwa/charting_library/static/images/prediction-failure-white.png"
  },
  {
    "revision": "4fafff07d8914dc11f6d335f606ff47c",
    "url": "/pwa/charting_library/static/images/prediction-success-white.png"
  },
  {
    "revision": "37a0b0d526f57fdfe7bef1333f5b36f1",
    "url": "/pwa/charting_library/static/images/select-bg.png"
  },
  {
    "revision": "7a4d6ce4f90c07141ad292e6034a45e3",
    "url": "/pwa/charting_library/static/images/sidetoolbar/instruments.png"
  },
  {
    "revision": "67aa5444b2b47ef43a787fd521cb1771",
    "url": "/pwa/charting_library/static/images/sidetoolbar/toolgroup.png"
  },
  {
    "revision": "4c67d316642ba9107520b700a5293e33",
    "url": "/pwa/charting_library/static/images/svg/chart/bucket2.svg"
  },
  {
    "revision": "ebde53c243a10d08f22808bcb21955e6",
    "url": "/pwa/charting_library/static/images/svg/chart/font.svg"
  },
  {
    "revision": "40566afd832a155e5e370a8bd423de4b",
    "url": "/pwa/charting_library/static/images/svg/chart/large-slider-handle.svg"
  },
  {
    "revision": "0778349b330aff337461b6b022e9177e",
    "url": "/pwa/charting_library/static/images/svg/chart/pencil2.svg"
  },
  {
    "revision": "63beed75ee32499e3d52ea3599768f71",
    "url": "/pwa/charting_library/static/images/svg/question-mark-rounded.svg"
  },
  {
    "revision": "ef184b625728ec530a7958618e0a3a86",
    "url": "/pwa/charting_library/static/images/tvcolorpicker-bg-gradient.png"
  },
  {
    "revision": "79f0e781be418df4a4d5b052ba1b61a2",
    "url": "/pwa/charting_library/static/images/tvcolorpicker-bg.png"
  },
  {
    "revision": "417aec8f751eaf532fa7760b2779716d",
    "url": "/pwa/charting_library/static/images/tvcolorpicker-check.png"
  },
  {
    "revision": "b738e5c5b8acbd9891b5f89d3fc6f274",
    "url": "/pwa/charting_library/static/images/tvcolorpicker-sprite.png"
  },
  {
    "revision": "f48fc323349e2e8242024175855c912a",
    "url": "/pwa/charting_library/static/images/warning-icon.png"
  },
  {
    "revision": "9f8395dae4215f6fcbf0c1174e06d839",
    "url": "/pwa/charting_library/static/it-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "081f8994c73ea258111c12ff85888f01",
    "url": "/pwa/charting_library/static/ja-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "31e8608be7504f165eba368e88c1c427",
    "url": "/pwa/charting_library/static/ko-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "2191e90481eb3207eea74b6da49b344b",
    "url": "/pwa/charting_library/static/lib/external/spin.min.js"
  },
  {
    "revision": "3eef0c2b01861a6269b6769ae92c055c",
    "url": "/pwa/charting_library/static/ms_MY-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "3e267dab00671c178c0a6c1a3621c880",
    "url": "/pwa/charting_library/static/nl_NL-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "1a092903ab3d2913e7327cd8fd688061",
    "url": "/pwa/charting_library/static/no-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "7f9c72be79a80dde8728b467045e44e6",
    "url": "/pwa/charting_library/static/pl-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "2e95dde82558444dc440fb0445c73f3c",
    "url": "/pwa/charting_library/static/pt-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "d913d0128e9572e0b3da129d4e497d16",
    "url": "/pwa/charting_library/static/ro-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "cb9f22ed68550fc3fca108c92e3a118c",
    "url": "/pwa/charting_library/static/ru-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "f5d17fc31f0f3e4da6a322ac5f6900c2",
    "url": "/pwa/charting_library/static/sk_SK-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "423f1668fc33be77a4fde71136e1d130",
    "url": "/pwa/charting_library/static/sv-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "27b14e4fed2f24e6b77e5c8882de43d8",
    "url": "/pwa/charting_library/static/th-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "d86af2a7f2bdc84e9ca5a3027883b2b1",
    "url": "/pwa/charting_library/static/tr-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "30e959f55c5b2032b602bfcd0519813c",
    "url": "/pwa/charting_library/static/vi-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "fdc77e35fd7b2b7062dce14fcb58bc51",
    "url": "/pwa/charting_library/static/zh-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "7ffec64b1b21946a0c2412d4df993b34",
    "url": "/pwa/charting_library/static/zh_TW-tv-chart.99e91cf53749c6852251.html"
  },
  {
    "revision": "5b7a838de6c0ce5f444181d3cab9188a",
    "url": "/pwa/config.json"
  },
  {
    "revision": "e1bc57b9c41061c0dac7",
    "url": "/pwa/css/PnLHistory.db49b199.css"
  },
  {
    "revision": "8a29074f2334344f56ba",
    "url": "/pwa/css/app.8e010757.css"
  },
  {
    "revision": "bbca1c89719efdf354b0",
    "url": "/pwa/css/bondAccount.651e43a0.css"
  },
  {
    "revision": "3c0cc6a0add14788db19",
    "url": "/pwa/css/burstHistory.d9574b2f.css"
  },
  {
    "revision": "ef55f1367e7704f3fb8c",
    "url": "/pwa/css/capitalRecord.854c00c3.css"
  },
  {
    "revision": "194d32ef4388601a72b1",
    "url": "/pwa/css/chunk-000bb062.8bf65085.css"
  },
  {
    "revision": "e78169474b3e339d7a29",
    "url": "/pwa/css/chunk-12183542.f161e9d4.css"
  },
  {
    "revision": "d08ff226773183d9f7e5",
    "url": "/pwa/css/chunk-18e9ee3d.33a770a9.css"
  },
  {
    "revision": "3c0dd6f264336fd7842c",
    "url": "/pwa/css/chunk-21d8d549.cd81e612.css"
  },
  {
    "revision": "820b1479201bade1f052",
    "url": "/pwa/css/chunk-329f8713.a1547e2d.css"
  },
  {
    "revision": "ecf058218e57b96b97c6",
    "url": "/pwa/css/chunk-3645de47.acc85859.css"
  },
  {
    "revision": "c5928e6cae3b27862b19",
    "url": "/pwa/css/chunk-524316f5.d6a4701a.css"
  },
  {
    "revision": "a254417e4b306a7672c9",
    "url": "/pwa/css/chunk-6aad1fe4.c184a24f.css"
  },
  {
    "revision": "d588afb64873f99fedbc",
    "url": "/pwa/css/chunk-6f7206cd.9957a555.css"
  },
  {
    "revision": "ae5ac6839dc0f85855e5",
    "url": "/pwa/css/chunk-6fd430b7.97c6f964.css"
  },
  {
    "revision": "dfd00e11db9bb4e947bf",
    "url": "/pwa/css/chunk-7a2380a6.bf2c3bfe.css"
  },
  {
    "revision": "ba572c9909576bbb31bd",
    "url": "/pwa/css/chunk-e600dd58.ff9f37eb.css"
  },
  {
    "revision": "3e050d68c21791a5a7d4",
    "url": "/pwa/css/chunk-e872d378.8cbb1dd0.css"
  },
  {
    "revision": "bbd673b165a936ff64ad",
    "url": "/pwa/css/chunk-ee340e7c.d971bf46.css"
  },
  {
    "revision": "93e670cdbf5e3cda4da7",
    "url": "/pwa/css/chunk-eeb86734.9cb941bd.css"
  },
  {
    "revision": "1d79181466f31f856556",
    "url": "/pwa/css/chunk-vendors.12f36875.css"
  },
  {
    "revision": "3eac89ed5dd26a2dcef6",
    "url": "/pwa/css/deliveryHistory.c5e9b465.css"
  },
  {
    "revision": "ba72fff12644eef77af7",
    "url": "/pwa/css/details.6ec61c19.css"
  },
  {
    "revision": "bef4e007382236ce5bc0",
    "url": "/pwa/css/futuresInfo.f622d095.css"
  },
  {
    "revision": "a022793c3431149205bb",
    "url": "/pwa/css/insuranceFount.013a6ce7.css"
  },
  {
    "revision": "3efedae68e68c54e47be",
    "url": "/pwa/css/quotesIndex.6b72627b.css"
  },
  {
    "revision": "af164d1836663e43535e",
    "url": "/pwa/css/riskNotice.b9e4ddc2.css"
  },
  {
    "revision": "cd19635f50bee98acb64",
    "url": "/pwa/css/transfer.80454451.css"
  },
  {
    "revision": "2e790f838ac503dc1759",
    "url": "/pwa/css/transfer_follow.b6fefb3f.css"
  },
  {
    "revision": "399ef6f152e3ea7a87e3",
    "url": "/pwa/css/transfer_follow_his.6b47dc4a.css"
  },
  {
    "revision": "83a582745e742b66894f",
    "url": "/pwa/css/transfer_his.76390a28.css"
  },
  {
    "revision": "c60c4d39f83feebe9d441d487e67336e",
    "url": "/pwa/fonts/cubeic.c60c4d39.woff"
  },
  {
    "revision": "dcc2b6f1e42abe71bc9f1a83f85f47d4",
    "url": "/pwa/fonts/cubeic.dcc2b6f1.ttf"
  },
  {
    "revision": "ea107ae95d15b396d820cdcfef731317",
    "url": "/pwa/gt.js"
  },
  {
    "revision": "00c4136d1830e65399cc0ea833c66614",
    "url": "/pwa/img/404.00c4136d.png"
  },
  {
    "revision": "d1babbf9cdeae2adfe32f21fb1221cd1",
    "url": "/pwa/img/404@2x.d1babbf9.png"
  },
  {
    "revision": "e0b7d183111100207bbd8747dff382b4",
    "url": "/pwa/img/bg-top.e0b7d183.png"
  },
  {
    "revision": "d008b99f3b904c96169c0144d20dec1b",
    "url": "/pwa/img/bonusbg1@1x.d008b99f.png"
  },
  {
    "revision": "4ee561536ebd8b8fae8a540b23fdfac5",
    "url": "/pwa/img/bonusbg1@2x.4ee56153.png"
  },
  {
    "revision": "44256a9e4e3720e38650c13d93150d8d",
    "url": "/pwa/img/bonusbg2@2x.44256a9e.png"
  },
  {
    "revision": "c3597b63da94758c9ff800bc508b8d07",
    "url": "/pwa/img/bonusbg3@1x.c3597b63.png"
  },
  {
    "revision": "5973d740b279fae6ffd93c0320368a2b",
    "url": "/pwa/img/bonusbg3@2x.5973d740.png"
  },
  {
    "revision": "4e5392e20634db1597a949c593a3862a",
    "url": "/pwa/img/btn1.4e5392e2.png"
  },
  {
    "revision": "5e86f31aced1ac10662fc7fdc5e8c267",
    "url": "/pwa/img/chaojidaili-en.5e86f31a.png"
  },
  {
    "revision": "7e7c637b5ec2d7eb8d62676de8cdb194",
    "url": "/pwa/img/chaojidaili-icon.7e7c637b.png"
  },
  {
    "revision": "ae2be8a9824fa3b2fa4de46640e7c53b",
    "url": "/pwa/img/chaojidaili-zh.ae2be8a9.png"
  },
  {
    "revision": "dbe78bb00eaeac85d21b4e8eb1df8d5b",
    "url": "/pwa/img/chaojifanli-en.dbe78bb0.png"
  },
  {
    "revision": "bccaa63826bcea720f8388c04b2011bd",
    "url": "/pwa/img/chaojifanli-icon.bccaa638.png"
  },
  {
    "revision": "cf4bf90b68cf6c285bfff3783bd4ee58",
    "url": "/pwa/img/chaojifanli-zh.cf4bf90b.png"
  },
  {
    "revision": "0fcf24a8d524bb24222b9e57e1c7c50d",
    "url": "/pwa/img/chuangshi.0fcf24a8.png"
  },
  {
    "revision": "b302045adda00257147792a8736bd45d",
    "url": "/pwa/img/e_iconstatus1@1x.b302045a.png"
  },
  {
    "revision": "2b5b0bdbb306ad9fd6eafcbb22e3a82c",
    "url": "/pwa/img/e_iconstatus1@2x.2b5b0bdb.png"
  },
  {
    "revision": "8dabebc8337018689c8a37a5bd8af91b",
    "url": "/pwa/img/e_iconstatus2@2x.8dabebc8.png"
  },
  {
    "revision": "a8fd7f294a815826b333728e52cda001",
    "url": "/pwa/img/e_iconstatus3@2x.a8fd7f29.png"
  },
  {
    "revision": "cb41ebeb3aff8b0691ab20efda9d9652",
    "url": "/pwa/img/iconstatus1@2x.cb41ebeb.png"
  },
  {
    "revision": "f7d5c9bf17df53714a277700349ba85d",
    "url": "/pwa/img/iconstatus2@1x.f7d5c9bf.png"
  },
  {
    "revision": "f84e9b30ce0938c44d20e77f8a2e5b46",
    "url": "/pwa/img/iconstatus2@2x.f84e9b30.png"
  },
  {
    "revision": "f6f7ce4869271510daf1135208763cd0",
    "url": "/pwa/img/iconstatus3@2x.f6f7ce48.png"
  },
  {
    "revision": "4d43712d5165c29ca95021fc7dfc64a6",
    "url": "/pwa/img/jigou.4d43712d.png"
  },
  {
    "revision": "84b58640a3a60671b9b4bd6bea087806",
    "url": "/pwa/img/jinpai.84b58640.png"
  },
  {
    "revision": "54930805f3afa277c98082254757494c",
    "url": "/pwa/img/noNetwork.54930805.png"
  },
  {
    "revision": "524f872115012042e1e33a5d0a281975",
    "url": "/pwa/img/noNetwork@2x.524f8721.png"
  },
  {
    "revision": "18d74c579345a62b7789c663079f178d",
    "url": "/pwa/img/p1-en.18d74c57.png"
  },
  {
    "revision": "fa2a395e284ba2071cfdbd4c003d8106",
    "url": "/pwa/img/p1-icon.fa2a395e.png"
  },
  {
    "revision": "97e988cc0edf204faec57fd254ada484",
    "url": "/pwa/img/p1-zh.97e988cc.png"
  },
  {
    "revision": "9f917c09a5be955d48fa0bf144644e8d",
    "url": "/pwa/img/p1001-en.9f917c09.png"
  },
  {
    "revision": "7377eb008b0a96cc3f6e8dc7f586f876",
    "url": "/pwa/img/p1001-icon.7377eb00.png"
  },
  {
    "revision": "f321917fc457c71ec7d374076a968a3c",
    "url": "/pwa/img/p1001-zh.f321917f.png"
  },
  {
    "revision": "409b4b696a987a2593976d875a2963e3",
    "url": "/pwa/img/p1002-en.409b4b69.png"
  },
  {
    "revision": "d7aa3bc6299da4a4df8362dbae3a17c5",
    "url": "/pwa/img/p1002-icon.d7aa3bc6.png"
  },
  {
    "revision": "b5b00026abad14baa7a7b9ae178bab60",
    "url": "/pwa/img/p1002-zh.b5b00026.png"
  },
  {
    "revision": "4d3e4fd158adbf6034677b87d53d6e37",
    "url": "/pwa/img/p1003-en.4d3e4fd1.png"
  },
  {
    "revision": "a6ddf6df266923f2e758652be89f6f89",
    "url": "/pwa/img/p1003-icon.a6ddf6df.png"
  },
  {
    "revision": "921d9b278bd4e095d845bc9aad3886a2",
    "url": "/pwa/img/p1003-zh.921d9b27.png"
  },
  {
    "revision": "f5ee8643a151f87ebf858d570d559f61",
    "url": "/pwa/img/p1004-en.f5ee8643.png"
  },
  {
    "revision": "dc6daabdc0f5c984c269761c877db35c",
    "url": "/pwa/img/p1004-icon.dc6daabd.png"
  },
  {
    "revision": "f20e14762c404f45cd42fc5eea05c551",
    "url": "/pwa/img/p1004-zh.f20e1476.png"
  },
  {
    "revision": "3c5c2cd75b79a8902b803d3fcc9d874e",
    "url": "/pwa/img/p2-en.3c5c2cd7.png"
  },
  {
    "revision": "127964ccd01b5f2b3f14351fa2fb5a85",
    "url": "/pwa/img/p2-icon.127964cc.png"
  },
  {
    "revision": "b8e28944cc591a4f70daaa368c5f5011",
    "url": "/pwa/img/p2-zh.b8e28944.png"
  },
  {
    "revision": "9d558e1da25a764aef003111367a1645",
    "url": "/pwa/img/p3-en.9d558e1d.png"
  },
  {
    "revision": "c2f35f89518fa51bbcaceacd3cbbc6ba",
    "url": "/pwa/img/p3-icon.c2f35f89.png"
  },
  {
    "revision": "d16f613dc4cc031e6540b3554b7289a3",
    "url": "/pwa/img/p3-zh.d16f613d.png"
  },
  {
    "revision": "83cfdd5d6e122530546aa43e52922242",
    "url": "/pwa/img/p4-en.83cfdd5d.png"
  },
  {
    "revision": "9fd6a4e828bb1c6877bfade28399a498",
    "url": "/pwa/img/p4-icon.9fd6a4e8.png"
  },
  {
    "revision": "83bc90fe69a5febefabbee5a24038088",
    "url": "/pwa/img/p4-zh.83bc90fe.png"
  },
  {
    "revision": "674c53a22c3cd83e2acfbbc9592047cf",
    "url": "/pwa/img/p5-en.674c53a2.png"
  },
  {
    "revision": "dc2f93ab9af0a9e4ec6139b6c4f3a4a2",
    "url": "/pwa/img/p5-icon.dc2f93ab.png"
  },
  {
    "revision": "225c3b491e152a27b4e92e0cd5077d87",
    "url": "/pwa/img/p5-zh.225c3b49.png"
  },
  {
    "revision": "f7f38134ff2fd770109f140dd1ff1725",
    "url": "/pwa/img/p6-en.f7f38134.png"
  },
  {
    "revision": "8286bcc5fbfd77fb77b30ae557417ca5",
    "url": "/pwa/img/p6-icon.8286bcc5.png"
  },
  {
    "revision": "45366108fa12e06068d9ca4e1f23857c",
    "url": "/pwa/img/p6-zh.45366108.png"
  },
  {
    "revision": "9ff3d50e69c72e4a0b28b41b1be96fb4",
    "url": "/pwa/img/plan-banner-en.9ff3d50e.png"
  },
  {
    "revision": "49636b4b7012739ed4e19a5d789fb3b3",
    "url": "/pwa/img/plan-banner.49636b4b.png"
  },
  {
    "revision": "07f53691cd8b87047d3345bec2f2a684",
    "url": "/pwa/img/putong-icon.07f53691.png"
  },
  {
    "revision": "37dc4a871cf14b0531fd8a26750625cf",
    "url": "/pwa/img/putong-zh.37dc4a87.png"
  },
  {
    "revision": "d7d1a673b1c020d89c27837ef12d2f3d",
    "url": "/pwa/img/rank1.d7d1a673.png"
  },
  {
    "revision": "5928a04673a75f2d571b96026034b80a",
    "url": "/pwa/img/sunshine.5928a046.png"
  },
  {
    "revision": "0ea4c13b6bd4ce05c1708667296d1d03",
    "url": "/pwa/img/super1-icon.0ea4c13b.png"
  },
  {
    "revision": "67e6f5689210547ca9e79890b039d464",
    "url": "/pwa/img/super1-title.67e6f568.png"
  },
  {
    "revision": "d093426cda150e91556b6ec0f7e8b466",
    "url": "/pwa/img/system-card-bg.d093426c.png"
  },
  {
    "revision": "108abfc6c667f1b78e2a3e95ef3623c8",
    "url": "/pwa/img/system-card.108abfc6.png"
  },
  {
    "revision": "f8593f2b93dfe29a7528a2e2a48db0f1",
    "url": "/pwa/img/zuanshi.f8593f2b.png"
  },
  {
    "revision": "75ab6ae3dcbdf221b5f29a7d0b67d4ca",
    "url": "/pwa/img/光.75ab6ae3.png"
  },
  {
    "revision": "563204f21dfc2faf944fe03e6d8be9f4",
    "url": "/pwa/img/盒子内部.563204f2.png"
  },
  {
    "revision": "c98b9216683f63bf7b543a53b21e7afe",
    "url": "/pwa/img/盒子外部.c98b9216.png"
  },
  {
    "revision": "7a21ba6fceaebd036cb78b4dde34b62a",
    "url": "/pwa/img/盖子.7a21ba6f.png"
  },
  {
    "revision": "d9f14feffabca2805869ca815da4415d",
    "url": "/pwa/img/金币.d9f14fef.png"
  },
  {
    "revision": "9b6eb6f34e9b833536734d0785289b51",
    "url": "/pwa/index.html"
  },
  {
    "revision": "e1bc57b9c41061c0dac7",
    "url": "/pwa/js/PnLHistory.2d0b9d5a.js"
  },
  {
    "revision": "8a29074f2334344f56ba",
    "url": "/pwa/js/app.6a73d6c5.js"
  },
  {
    "revision": "bbca1c89719efdf354b0",
    "url": "/pwa/js/bondAccount.56ce0ed4.js"
  },
  {
    "revision": "3c0cc6a0add14788db19",
    "url": "/pwa/js/burstHistory.e4b49b42.js"
  },
  {
    "revision": "ef55f1367e7704f3fb8c",
    "url": "/pwa/js/capitalRecord.ee3af08d.js"
  },
  {
    "revision": "194d32ef4388601a72b1",
    "url": "/pwa/js/chunk-000bb062.17a07ccf.js"
  },
  {
    "revision": "e78169474b3e339d7a29",
    "url": "/pwa/js/chunk-12183542.7289f7c9.js"
  },
  {
    "revision": "d08ff226773183d9f7e5",
    "url": "/pwa/js/chunk-18e9ee3d.3e0ba8d0.js"
  },
  {
    "revision": "3c0dd6f264336fd7842c",
    "url": "/pwa/js/chunk-21d8d549.c57404b8.js"
  },
  {
    "revision": "820b1479201bade1f052",
    "url": "/pwa/js/chunk-329f8713.f99a729e.js"
  },
  {
    "revision": "ecf058218e57b96b97c6",
    "url": "/pwa/js/chunk-3645de47.7b7ef9cb.js"
  },
  {
    "revision": "c5928e6cae3b27862b19",
    "url": "/pwa/js/chunk-524316f5.ddb8ca7b.js"
  },
  {
    "revision": "a254417e4b306a7672c9",
    "url": "/pwa/js/chunk-6aad1fe4.bfa75a5e.js"
  },
  {
    "revision": "d588afb64873f99fedbc",
    "url": "/pwa/js/chunk-6f7206cd.8d7b125d.js"
  },
  {
    "revision": "ae5ac6839dc0f85855e5",
    "url": "/pwa/js/chunk-6fd430b7.e34030dc.js"
  },
  {
    "revision": "dfd00e11db9bb4e947bf",
    "url": "/pwa/js/chunk-7a2380a6.5f35b0de.js"
  },
  {
    "revision": "ba572c9909576bbb31bd",
    "url": "/pwa/js/chunk-e600dd58.6c88dd5e.js"
  },
  {
    "revision": "3e050d68c21791a5a7d4",
    "url": "/pwa/js/chunk-e872d378.0d9b0178.js"
  },
  {
    "revision": "bbd673b165a936ff64ad",
    "url": "/pwa/js/chunk-ee340e7c.7fac037d.js"
  },
  {
    "revision": "93e670cdbf5e3cda4da7",
    "url": "/pwa/js/chunk-eeb86734.02ad4321.js"
  },
  {
    "revision": "1d79181466f31f856556",
    "url": "/pwa/js/chunk-vendors.c4aeebe5.js"
  },
  {
    "revision": "3eac89ed5dd26a2dcef6",
    "url": "/pwa/js/deliveryHistory.78524cf0.js"
  },
  {
    "revision": "ba72fff12644eef77af7",
    "url": "/pwa/js/details.4746719b.js"
  },
  {
    "revision": "bef4e007382236ce5bc0",
    "url": "/pwa/js/futuresInfo.2bc5cc48.js"
  },
  {
    "revision": "a022793c3431149205bb",
    "url": "/pwa/js/insuranceFount.bb9e1e21.js"
  },
  {
    "revision": "3efedae68e68c54e47be",
    "url": "/pwa/js/quotesIndex.90492e49.js"
  },
  {
    "revision": "af164d1836663e43535e",
    "url": "/pwa/js/riskNotice.8e371dc1.js"
  },
  {
    "revision": "cd19635f50bee98acb64",
    "url": "/pwa/js/transfer.e50defcb.js"
  },
  {
    "revision": "2e790f838ac503dc1759",
    "url": "/pwa/js/transfer_follow.8e386049.js"
  },
  {
    "revision": "399ef6f152e3ea7a87e3",
    "url": "/pwa/js/transfer_follow_his.f25879de.js"
  },
  {
    "revision": "83a582745e742b66894f",
    "url": "/pwa/js/transfer_his.1fe7ff4c.js"
  },
  {
    "revision": "dcbe1fc938fb2ce2d3c739ecf7cd11d5",
    "url": "/pwa/manifest.json"
  },
  {
    "revision": "cf24efc212a33851158648118e8c5e8b",
    "url": "/pwa/plusShare.js"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/pwa/robots.txt"
  },
  {
    "revision": "6a11043803fcd0799aa195c72c7554a1",
    "url": "/pwa/tabbar/asset-active.png"
  },
  {
    "revision": "791af592e65cf9122fc399054754b5b3",
    "url": "/pwa/tabbar/asset.png"
  },
  {
    "revision": "63693f445a3770b04bf4d03ae4696bb9",
    "url": "/pwa/tabbar/consultation-active.png"
  },
  {
    "revision": "2552ffbfbf5dd224e8523c8232e69c54",
    "url": "/pwa/tabbar/consultation.png"
  },
  {
    "revision": "2acbabe185eb246717325c8de69c3447",
    "url": "/pwa/tabbar/futures-active.png"
  },
  {
    "revision": "a68652a642ccd1df5e9ac42dbaf0ec45",
    "url": "/pwa/tabbar/futures.png"
  },
  {
    "revision": "e7a25c85b21cf468c205e747769dc3c9",
    "url": "/pwa/tabbar/home-active.png"
  },
  {
    "revision": "c2b6bb23a7ea4e330daecd281e81600f",
    "url": "/pwa/tabbar/home.png"
  },
  {
    "revision": "af395f438a61d1d7292901862fae772c",
    "url": "/pwa/tabbar/lightning.png"
  },
  {
    "revision": "d3d209a80ea398500a934835b747d4ba",
    "url": "/pwa/tabbar/lightning@2x.png"
  },
  {
    "revision": "5780cef3ffd12c0e997b1d9517400722",
    "url": "/pwa/tabbar/lightning_s.png"
  },
  {
    "revision": "2fc834ee845da30c7cd622dbcb246f0b",
    "url": "/pwa/tabbar/lightning_s@2x.png"
  },
  {
    "revision": "c58cd71989352ee0cccc0933361fb3ee",
    "url": "/pwa/tabbar/quotes-active.png"
  },
  {
    "revision": "e7c7e5aa0989d97227f157bc23704f8c",
    "url": "/pwa/tabbar/quotes.png"
  },
  {
    "revision": "7f6673e5a7a6768de0be4442ed58e895",
    "url": "/pwa/tabbar/sliders-fill-active.png"
  },
  {
    "revision": "bedb0b9aa5fd089def2d20ecdfb1ed7f",
    "url": "/pwa/tabbar/sliders-fill-active@2x.png"
  },
  {
    "revision": "ab3dab328030922481ed649082337467",
    "url": "/pwa/tabbar/sliders-fill.png"
  },
  {
    "revision": "f3718849fb41535e79bfb2dff5de98ee",
    "url": "/pwa/tabbar/sliders-fill@2x.png"
  }
]);